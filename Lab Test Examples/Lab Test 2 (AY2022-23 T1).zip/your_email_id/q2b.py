# Name:
# Email ID:

def filter_words(filename, end):
    # Replace the code below with your implementation.
    return
