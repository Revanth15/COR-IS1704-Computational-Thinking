# Name:
# Email ID:

def check_record(record):
    # Replace the code below with your implementation.
    return
