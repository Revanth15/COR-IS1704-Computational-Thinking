# Name:
# Email ID:

def get_n_odd_numbers(filename, n):
    # Replace the code below with your implementation.
    
    return
