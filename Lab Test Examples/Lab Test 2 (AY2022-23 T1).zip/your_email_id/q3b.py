# Name:
# Email ID:

from q3a import read_courses

def calculate_student_gpa(filename, start_term, end_term):
    # Replace the code below with your implementation.
    return {} 

