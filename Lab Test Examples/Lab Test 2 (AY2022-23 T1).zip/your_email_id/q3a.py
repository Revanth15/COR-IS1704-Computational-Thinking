# Name:
# Email ID:

def read_courses(filename):
    # Replace the code below with your implementation.
    return {}
