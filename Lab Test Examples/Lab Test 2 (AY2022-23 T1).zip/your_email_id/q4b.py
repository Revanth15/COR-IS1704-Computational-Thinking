# Name:
# Email ID:

def find_words(word_list, input_str, step):
    # Replace the code below with your implementation.
    
    return